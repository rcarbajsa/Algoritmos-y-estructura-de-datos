package aed.find;

import es.upm.aedlib.tree.Tree;
import es.upm.aedlib.Position;


public class Find {

  /**
   * Busca ficheros con nombre igual que fileName dentro el arbol directory,
   * y devuelve un PositionList con el nombre completo de los ficheros
   * (incluyendo el camino).
   */
  public static void find(String fileName, Tree<String> directory) {
    // Cambio el cuerpo de este metodo
  }
}
